-- OT5_drop_seq.sql
-- Student ID: 
-- Student Name:

set echo on;
-- Write your code below
DROP SEQUENCE LOCATION_SEQ;
DROP SEQUENCE TRIP_SEQ;



set echo off;