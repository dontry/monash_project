-- OT4_seq.sql
-- Student ID: 
-- Student Name:

set echo on;
-- Write your code below
CREATE SEQUENCE LOCATION_SEQ START WITH 42 INCREMENT BY 1;
CREATE SEQUENCE TRIP_SEQ  START WITH 1244 INCREMENT BY 1;


set echo off;